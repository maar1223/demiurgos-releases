"""Backend-owned contracts and state boundary for guided character creation.

This module deliberately stops before routing, graph access, or persistence.  Hermes
is treated as an untrusted, bounded proposal provider; the in-memory store is the
authoritative seam that can later be replaced by the existing session persistence.
"""

from __future__ import annotations

import asyncio
import logging
from copy import deepcopy
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Awaitable, Callable, Mapping, Protocol

from guided_flow import GuidedFlowProfile


logger = logging.getLogger(__name__)

PROTOCOL_VERSION = "guided-character-v1"
# Guided turns are full model runs; observed latencies (31s, p95 ~63s) exceed
# the former 30s ceiling and cancelled otherwise valid answers. Keep a single
# bounded default and maximum so validation never widens implicitly.
DEFAULT_DEADLINE_MS = 90_000
MAX_DEADLINE_MS = 90_000

#: Provider-declared turn intents (S5). ``answer`` is the implicit default;
#: ``explore`` marks a world-exploration turn, which commits nothing.
EXPLORE_INTENTS = frozenset({"answer", "explore"})
EXPLORE_INTENT = "explore"


class ErrorCode(StrEnum):
    INVALID_INPUT = "invalid_input"
    CAPABILITY_UNAVAILABLE = "capability_unavailable"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"
    PROVIDER_UNAVAILABLE = "provider_unavailable"
    MALFORMED_OUTPUT = "malformed_output"
    UNAUTHORIZED = "unauthorized"
    REVISION_CONFLICT = "revision_conflict"
    INTERNAL = "internal"


@dataclass(frozen=True)
class StructuredError:
    code: ErrorCode
    message: str
    retryable: bool

    def as_dict(self) -> dict[str, object]:
        return {"code": self.code.value, "message": self.message, "retryable": self.retryable}


@dataclass(frozen=True)
class Capabilities:
    protocol_version: str
    guided_character_v1: bool
    cancellation: bool
    structured_output: bool
    max_deadline_ms: int

    @classmethod
    def from_payload(cls, payload: object) -> "Capabilities | None":
        if not isinstance(payload, Mapping):
            return None
        values = {"protocol_version", "guided_character_v1", "cancellation", "structured_output", "max_deadline_ms"}
        if set(payload) & values != values:
            return None
        deadline = payload["max_deadline_ms"]
        if not isinstance(deadline, int) or isinstance(deadline, bool) or deadline <= 0:
            return None
        return cls(
            protocol_version=payload["protocol_version"], guided_character_v1=payload["guided_character_v1"],
            cancellation=payload["cancellation"], structured_output=payload["structured_output"],
            max_deadline_ms=deadline,
        ) if isinstance(payload["protocol_version"], str) and all(
            isinstance(payload[name], bool) for name in ("guided_character_v1", "cancellation", "structured_output")
        ) else None

    def admitted(self) -> bool:
        return (
            self.protocol_version == PROTOCOL_VERSION and self.guided_character_v1
            and self.cancellation and self.structured_output and self.max_deadline_ms > 0
        )


@dataclass(frozen=True)
class GuidedRequest:
    protocol_version: str
    request_id: str
    session_id: str
    world: str
    base_revision: int
    authorization_binding: str
    author_input: str
    context_budget: int = 4_000
    deadline_ms: int = DEFAULT_DEADLINE_MS
    reference_context: str = ""
    reference_name: str | None = None
    relation_goal: str = ""
    turn_mode: str = "creation"
    guided_mode: str = "full"
    question_depth: str = "standard"
    methodology: str | None = None
    # Server-resolved, read-only world lore for this turn (S2). Bounded by the
    # same context budget as the reference; the provider cannot fetch it.
    world_context: str = ""
    # Compact, server-owned summary of what the author already answered. It
    # keeps the provider from re-asking resolved facts (S1).
    known_state: str = ""
    # Kernel entity shape of the pinned flow (e.g. ``personaje``). Additive:
    # legacy pins send the empty string and get the identical prompt.
    flow_entity_type: str = ""
    # The author's chosen creation path (``explore`` 40/60 or ``fields``
    # questionnaire). Additive: legacy callers get the exploratory prompt.
    guided_path: str = "explore"
    # The current field brief in the questionnaire path (label, what it
    # expects, examples). Empty outside that path.
    field_context: str = ""
    # S2 (guided-turn-directive): the plan field this turn asks about, and the
    # progress snapshot taken when the server decided it. The provider must echo
    # the key; a different or missing echo becomes the server's fallback text.
    field_key: str = ""
    field_progress: Mapping[str, Any] | None = None

    def _oversized_fields(self) -> list[str]:
        """Names of the bounded fields that exceed ``context_budget``."""
        return [
            name
            for name, value in (
                ("reference_context", self.reference_context),
                ("relation_goal", self.relation_goal),
                ("world_context", self.world_context),
                ("known_state", self.known_state),
            )
            if isinstance(value, str) and len(value) > self.context_budget
        ]

    def validate(self) -> StructuredError | None:
        if self.protocol_version != PROTOCOL_VERSION or not isinstance(self.reference_context, str) or not all(
            isinstance(value, str) and value.strip() for value in
            (self.request_id, self.session_id, self.world, self.authorization_binding, self.author_input)
        ) or self.base_revision < 0 or self.context_budget <= 0 or (self.reference_name is not None and (not isinstance(self.reference_name, str) or not self.reference_name.strip())) or not isinstance(self.relation_goal, str) or not isinstance(self.world_context, str) or not isinstance(self.known_state, str) or self.turn_mode not in {"creation", "factual"} or self.guided_mode not in {"full", "fast"} or self.question_depth not in {"standard", "fundamental"}:
            return StructuredError(ErrorCode.INVALID_INPUT, "The guided request is invalid.", False)
        oversized = self._oversized_fields()
        if oversized:
            # Name every offending field. A bare "invalid" hid a whole
            # session's 422s behind the generic blocked copy (2026-11-08).
            return StructuredError(
                ErrorCode.INVALID_INPUT,
                "The guided request is invalid: "
                f"{', '.join(oversized)} exceeds the context budget.",
                False,
            )
        if not 1 <= self.deadline_ms <= MAX_DEADLINE_MS:
            return StructuredError(ErrorCode.INVALID_INPUT, "The deadline is outside the allowed bounds.", False)
        return None


class Outcome(StrEnum):
    QUESTION = "question"
    DELTA = "delta"
    CONFLICT = "conflict"
    UNAVAILABLE = "unavailable"
    ERROR = "error"


_TRUNCATION_SENTENCE_ENDS = (".", "!", "?", "\n")
_TRUNCATION_ELLIPSIS = "…"


def _bounded_text(text: str, limit: int) -> str:
    """Bound ``text`` without cutting a word in half.

    A hard slice mid-word (``"…los marcará púrp"``) reads as a broken message in
    the chat. Prefer the last complete sentence that keeps at least half the
    budget; otherwise cut at the last word boundary and mark the elision.
    """
    value = text.strip()
    if len(value) <= limit:
        return value
    window = value[:limit]
    sentence_end = max(
        (window.rfind(mark) for mark in _TRUNCATION_SENTENCE_ENDS), default=-1
    )
    if sentence_end >= limit // 2:
        return window[: sentence_end + 1].rstrip()
    word_end = window.rfind(" ")
    if word_end > 0:
        return window[:word_end].rstrip() + _TRUNCATION_ELLIPSIS
    return window + _TRUNCATION_ELLIPSIS


@dataclass(frozen=True)
class GuidedResponse:
    protocol_version: str
    request_id: str
    session_id: str
    base_revision: int
    outcome: Outcome
    provenance: tuple[str, ...] = ()
    question: str | None = None
    delta: Mapping[str, Any] | None = None
    provider_run_id: str | None = None
    retryable: bool = False
    error: StructuredError | None = None
    # S1: a short "what we have so far" reading that accompanies a question.
    # Optional and bounded; legacy providers that never send it keep the exact
    # pre-change envelope.
    synthesis: str | None = None
    # S1: non-canon observations the provider noticed this turn. Applied to the
    # candidate proposals (never to canon) so the session accumulates what was
    # collected instead of starting each question from nothing.
    observations: Mapping[str, Any] | None = None
    # S2 (guided-world-exploration): the author asked about the world instead of
    # answering the current field. ``answer`` carries the exploration reply as
    # its own block (never squeezed into the 3-sentence synthesis) and
    # ``intent`` marks the turn as non-committing so the cursor keeps its place.
    answer: str | None = None
    intent: str | None = None
    # S4: the plan field the provider says it asked about. Compared with the
    # request's key; a mismatch keeps the extraction and replaces the text.
    field_key: str | None = None

    # Three short sentences, not six paragraphs: the public state renders this
    # block before the question, so a 2,000-char cap produced walls of text.
    SYNTHESIS_MAX_CHARS = 700
    # An exploration answer is allowed to be a real answer, not a summary.
    ANSWER_MAX_CHARS = 2_000

    @classmethod
    def from_provider(cls, value: object, request: GuidedRequest) -> "GuidedResponse | None":
        if not isinstance(value, Mapping) or value.get("protocol_version") != PROTOCOL_VERSION:
            return None
        if value.get("request_id") != request.request_id or value.get("session_id") != request.session_id:
            return None
        try:
            outcome = Outcome(value["outcome"])
        except (KeyError, ValueError):
            return None
        question = value.get("question")
        delta = value.get("delta")
        if outcome is Outcome.QUESTION and (not isinstance(question, str) or not question.strip()):
            return None
        if outcome is Outcome.DELTA and not isinstance(delta, Mapping):
            return None
        provenance = value.get("provenance", ())
        if not isinstance(provenance, (list, tuple)) or not all(isinstance(item, str) for item in provenance):
            return None
        synthesis = value.get("synthesis")
        if synthesis is not None:
            if not isinstance(synthesis, str):
                return None
            synthesis = _bounded_text(synthesis, cls.SYNTHESIS_MAX_CHARS) or None
        answer = value.get("answer")
        if answer is not None:
            if not isinstance(answer, str):
                # Fail-safe (S5): an unusable answer degrades to a legacy turn.
                answer = None
            else:
                answer = _bounded_text(answer, cls.ANSWER_MAX_CHARS) or None
        intent = value.get("intent")
        if intent not in EXPLORE_INTENTS:
            intent = None
        echoed_field = value.get("field_key")
        if not isinstance(echoed_field, str):
            echoed_field = None
        observations = value.get("observations")
        if observations is not None and not isinstance(observations, Mapping):
            return None
        return cls(PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision, outcome,
                   tuple(provenance), question if isinstance(question, str) else None,
                   dict(delta) if isinstance(delta, Mapping) else None,
                   value.get("provider_run_id") if isinstance(value.get("provider_run_id"), str) else None,
                   value.get("retryable") is True,
                   synthesis=synthesis,
                   observations=dict(observations) if isinstance(observations, Mapping) else None,
                   answer=answer,
                   intent=intent,
                   field_key=echoed_field)


class MessageType(StrEnum):
    AUTHOR_INPUT = "author_input"
    ASSISTANT_RESPONSE = "assistant_response"
    PROPOSAL = "proposal"
    ACCEPTANCE = "acceptance"
    REJECTION = "rejection"
    ERROR = "error"
    RECOVERY = "recovery"


@dataclass(frozen=True)
class MethodologySnapshot:
    """Immutable methodology/version pin for one guided session.

    ``skill_id`` / ``skill_version`` identify the active methodology and
    ``compiled_contract_digest`` is the compiled contract identity. ``flow_type``
    is the guided-flow slot the pin belongs to (SR1): ``None`` means the
    guided-character slot (backward-compatible with pre-SR1 pins). The snapshot
    is server-issued at session creation and never rewritten; applying a
    methodology change requires a brand-new session.
    """

    skill_id: str | None = None
    skill_version: str | None = None
    compiled_contract_digest: str | None = None
    flow_type: str | None = None
    # The resolved flow profile pinned for this session (S1). ``None`` for
    # sessions created before the profile model; callers fall back to the
    # character contract, so no stored session changes behavior.
    profile: Mapping[str, Any] | None = None

    def as_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "skill_id": self.skill_id,
            "skill_version": self.skill_version,
            "compiled_contract_digest": self.compiled_contract_digest,
            "flow_type": self.flow_type,
        }
        # Additive: legacy pins serialize byte-identically (no ``profile`` key).
        if self.profile is not None:
            payload["profile"] = dict(self.profile)
        return payload


@dataclass(frozen=True)
class TypedMessage:
    message_type: MessageType
    content: Mapping[str, Any]
    revision: int


@dataclass
class CandidateState:
    accepted_canon: dict[str, Any] = field(default_factory=dict)
    proposals: dict[str, Any] = field(default_factory=dict)
    # Internal, non-canon notes the provider extracted from a turn. They feed
    # the "known so far" prompt but are NOT user-facing proposals: the Author
    # never accepts/rejects them (S1).
    observations: dict[str, Any] = field(default_factory=dict)
    unknowns: list[Any] = field(default_factory=list)
    rumors: list[Any] = field(default_factory=list)
    conflicts: list[Any] = field(default_factory=list)
    unresolved_references: list[Any] = field(default_factory=list)
    provenance: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class TurnDecision:
    """The one decision a committed question turn made (S2).

    Everything the author sees about "where we are" renders from this record:
    the pending question, the field card and its progress. Every consumer reads
    it; nobody recomputes the view a previous turn already decided.
    """

    kind: str
    question: str
    field_key: str | None = None
    field_label: str | None = None
    field_progress: Mapping[str, Any] | None = None
    source: str = "server"
    revision: int = 0
    directive_version: int = 1

    #: Kinds that carry a questionnaire cursor.
    FIELD_KINDS = frozenset({"field", "complete"})
    KINDS = frozenset({"path", "level", "field", "complete", "free"})

    def as_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "question": self.question,
            "field_key": self.field_key,
            "field_label": self.field_label,
            "field_progress": dict(self.field_progress) if self.field_progress else None,
            "source": self.source,
            "revision": self.revision,
            "directive_version": self.directive_version,
        }

    @classmethod
    def from_mapping(cls, value: Any) -> "TurnDecision | None":
        if not isinstance(value, Mapping):
            return None
        kind = value.get("kind")
        question = value.get("question")
        if kind not in cls.KINDS or not isinstance(question, str) or not question.strip():
            return None
        progress = value.get("field_progress")
        return cls(
            kind=str(kind),
            question=question,
            field_key=str(value["field_key"]) if isinstance(value.get("field_key"), str) else None,
            field_label=str(value["field_label"]) if isinstance(value.get("field_label"), str) else None,
            field_progress=dict(progress) if isinstance(progress, Mapping) else None,
            source=str(value.get("source") or "server"),
            revision=int(value.get("revision") or 0),
            directive_version=int(value.get("directive_version") or 1),
        )


@dataclass
class SessionState:
    session_id: str
    world: str
    phase: str
    revision: int
    authorization_binding: str
    messages: list[TypedMessage] = field(default_factory=list)
    pending_question: str | None = None
    candidate: CandidateState = field(default_factory=CandidateState)
    reference_context: str = ""
    reference_name: str | None = None
    relation_goal: str = ""
    confirmation_input: str = ""
    mode: str = "full"
    depth: str = "standard"
    # The chosen creation path: exploratory 40/60 or field-by-field questionnaire.
    path: str = "explore"
    # Fields the author explicitly skipped in the questionnaire (revisitable).
    skipped_fields: list[str] = field(default_factory=list)
    methodology_snapshot: MethodologySnapshot | None = None
    # S2: the decision the last committed question turn made. ``None`` for
    # legacy rows; the public state then falls back to deriving the cursor.
    turn_decision: TurnDecision | None = None


def session_flow_profile(state: SessionState) -> GuidedFlowProfile | None:
    """Resolve the profile pinned on the session, or ``None`` for legacy pins."""
    snapshot = state.methodology_snapshot
    if snapshot is None or snapshot.profile is None:
        return None
    return GuidedFlowProfile.from_dict(snapshot.profile)


def should_record_author_input(state: SessionState, author_input: str) -> bool:
    """Whether a commit must append the Author's turn to the transcript.

    The confirmation re-send carries the seed input that ``begin_confirmation``
    already stored; appending it again would duplicate the Author's turn. Every
    other turn is recorded so a durable transcript never loses the Author side.
    """
    if not author_input:
        return False
    if (
        state.phase == "conversation"
        and state.revision == 2
        and state.confirmation_input == author_input
    ):
        return False
    return True


class Provider(Protocol):
    async def invoke(self, request: GuidedRequest, cancellation: "CancellationToken") -> object: ...


class CancellationToken:
    def __init__(self) -> None:
        self._event = asyncio.Event()

    def cancel(self) -> None:
        self._event.set()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()


class GuidedSessionStore:
    """Revision and authorization checks are performed before every mutation."""

    def __init__(self) -> None:
        self._sessions: dict[str, SessionState] = {}

    def create(self, session_id: str, world: str, authorization_binding: str,
               reference_context: str = "", reference_name: str | None = None,
               relation_goal: str = "",
               mode: str = "full", depth: str = "standard",
               path: str = "explore",
               methodology_snapshot: "MethodologySnapshot | None" = None) -> SessionState:
        if session_id in self._sessions:
            raise ValueError("session already exists")
        if len(reference_context) > 4_000 or len(relation_goal) > 4_000:
            raise ValueError("reference context exceeds the bounded budget")
        if mode not in {"full", "fast"} or depth not in {"standard", "fundamental"}:
            raise ValueError("invalid guided mode")
        if path not in {"", "explore", "fields"}:
            raise ValueError("invalid guided path")
        state = SessionState(
            session_id, world, "conversation", 0, authorization_binding,
            reference_context=reference_context,
            reference_name=reference_name,
            relation_goal=relation_goal,
            mode=mode,
            depth=depth,
            path=path,
            methodology_snapshot=methodology_snapshot,
        )
        self._sessions[session_id] = state
        return deepcopy(state)

    def set_path(self, session_id: str, authorization_binding: str,
                 path: str) -> SessionState | None:
        """Pin the chosen creation path once the author answers the first turn."""
        state = self._sessions.get(session_id)
        if not state or state.authorization_binding != authorization_binding:
            return None
        if path not in {"explore", "fields"}:
            return None
        next_state = deepcopy(state)
        next_state.path = path
        self._sessions[session_id] = next_state
        return deepcopy(next_state)

    def set_level(self, session_id: str, authorization_binding: str,
                  level: str) -> SessionState | None:
        """Pin the author's narrative-level choice (drives the field plan)."""
        state = self._sessions.get(session_id)
        if not state or state.authorization_binding != authorization_binding:
            return None
        if level not in {"1º", "2º", "3º"}:
            return None
        next_state = deepcopy(state)
        next_state.candidate.accepted_canon["nivel"] = level
        self._sessions[session_id] = next_state
        return deepcopy(next_state)

    def skip_field(self, session_id: str, authorization_binding: str,
                   field_key: str) -> SessionState | None:
        """Record one explicitly skipped questionnaire field (idempotent)."""
        state = self._sessions.get(session_id)
        if not state or state.authorization_binding != authorization_binding:
            return None
        if not field_key or state.path != "fields":
            return None
        next_state = deepcopy(state)
        if field_key not in next_state.skipped_fields:
            next_state.skipped_fields.append(field_key)
        self._sessions[session_id] = next_state
        return deepcopy(next_state)

    def recover(self, session_id: str, authorization_binding: str) -> SessionState | None:
        state = self._sessions.get(session_id)
        return deepcopy(state) if state and state.authorization_binding == authorization_binding else None

    def methodology_snapshot(self, session_id: str, authorization_binding: str) -> MethodologySnapshot | None:
        """Return the pinned methodology snapshot for an owned session, if any."""
        state = self._sessions.get(session_id)
        if state is None or state.authorization_binding != authorization_binding:
            return None
        return state.methodology_snapshot

    def requires_revalidation(self, session_id: str, authorization_binding: str) -> bool:
        """In-memory sessions never need post-restart revalidation."""
        return False

    def revalidate_pending(self, session_id: str, authorization_binding: str,
                           base_revision: int, now: object = None) -> SessionState | None:
        """Revalidation seam for the in-memory store (no-op beyond recover)."""
        state = self._sessions.get(session_id)
        if not state or state.authorization_binding != authorization_binding:
            return None
        if state.revision != base_revision or state.phase == "complete":
            return None
        return deepcopy(state)

    def discard_expired(self, now: object = None) -> int:
        """In-memory sessions have no TTL; nothing is discarded."""
        return 0

    def begin_confirmation(self, session_id: str, authorization_binding: str, author_input: str, question: str) -> SessionState | None:
        state = self._sessions.get(session_id)
        if not state or state.authorization_binding != authorization_binding or state.revision != 0:
            return None
        next_state = deepcopy(state)
        next_state.phase = "confirmation"
        next_state.revision = 1
        next_state.confirmation_input = author_input
        next_state.pending_question = question
        next_state.messages.extend((
            TypedMessage(MessageType.AUTHOR_INPUT, {"text": author_input}, next_state.revision),
            TypedMessage(MessageType.ASSISTANT_RESPONSE, {"text": question}, next_state.revision),
        ))
        self._sessions[session_id] = next_state
        return deepcopy(next_state)

    def resolve_confirmation(self, session_id: str, authorization_binding: str, base_revision: int,
                             accepted: bool | None, clarification: str) -> SessionState | None:
        state = self._sessions.get(session_id)
        if not state or state.authorization_binding != authorization_binding or state.revision != base_revision:
            return None
        next_state = deepcopy(state)
        next_state.revision += 1
        if accepted is True:
            next_state.phase = "conversation"
            next_state.pending_question = None
            next_state.messages.append(TypedMessage(MessageType.AUTHOR_INPUT, {"text": "confirmed"}, next_state.revision))
        elif accepted is False:
            next_state.phase = "complete"
            next_state.pending_question = None
            next_state.confirmation_input = ""
            next_state.messages.append(TypedMessage(MessageType.ASSISTANT_RESPONSE, {"text": clarification}, next_state.revision))
        else:
            next_state.pending_question = clarification
            next_state.messages.append(TypedMessage(MessageType.ASSISTANT_RESPONSE, {"text": clarification}, next_state.revision))
        self._sessions[session_id] = next_state
        return deepcopy(next_state)

    def commit(
        self,
        request: GuidedRequest,
        response: GuidedResponse,
        decision: "TurnDecision | None" = None,
    ) -> SessionState | None:
        state = self._sessions.get(request.session_id)
        if not state or state.authorization_binding != request.authorization_binding or state.revision != request.base_revision:
            return None
        next_state = deepcopy(state)
        if not next_state.reference_context and request.reference_context:
            next_state.reference_context = request.reference_context[:request.context_budget]
            next_state.reference_name = request.reference_name
            next_state.relation_goal = request.relation_goal
        if should_record_author_input(next_state, request.author_input):
            next_state.messages.append(TypedMessage(
                MessageType.AUTHOR_INPUT, {"text": request.author_input},
                next_state.revision,
            ))
        next_state.revision += 1
        content: dict[str, object] = {"question": response.question} if response.question else dict(response.delta or {})
        if response.synthesis:
            content["synthesis"] = response.synthesis
        next_state.messages.append(TypedMessage(
            MessageType.ASSISTANT_RESPONSE if response.outcome is Outcome.QUESTION else MessageType.PROPOSAL,
            content, next_state.revision,
        ))
        next_state.pending_question = response.question
        if decision is not None:
            next_state.turn_decision = decision
        if response.observations:
            # Internal notes: never a public proposal, always available to the
            # gate and to the next provider run.
            next_state.candidate.observations.update(dict(response.observations))
        if response.outcome is Outcome.DELTA and response.delta:
            # Keep provider deltas outside canon and attach their provenance.
            from guided_character_domain import apply_delta
            apply_delta(next_state.candidate, response.delta, response.provenance)
        elif response.provenance:
            next_state.candidate.provenance.extend(response.provenance)
        self._sessions[request.session_id] = next_state
        return deepcopy(next_state)

    def accept_proposal(self, session_id: str, authorization_binding: str,
                        base_revision: int, key: str) -> SessionState | None:
        """Accept exactly one proposal after revision and authorization checks."""
        state = self._sessions.get(session_id)
        if not state or state.authorization_binding != authorization_binding or state.revision != base_revision:
            return None
        from guided_character_domain import accept_proposal
        next_state = deepcopy(state)
        accept_proposal(next_state.candidate, key)
        next_state.revision += 1
        next_state.messages.append(TypedMessage(MessageType.ACCEPTANCE, {"key": key}, next_state.revision))
        self._sessions[session_id] = next_state
        return deepcopy(next_state)

    def reject_proposal(self, session_id: str, authorization_binding: str,
                        base_revision: int, key: str) -> SessionState | None:
        """Reject exactly one proposal without promoting it to canon."""
        state = self._sessions.get(session_id)
        if not state or state.authorization_binding != authorization_binding or state.revision != base_revision:
            return None
        from guided_character_domain import reject_proposal
        next_state = deepcopy(state)
        reject_proposal(next_state.candidate, key)
        next_state.revision += 1
        next_state.messages.append(TypedMessage(MessageType.REJECTION, {"key": key}, next_state.revision))
        self._sessions[session_id] = next_state
        return deepcopy(next_state)

    def delete_for_world(self, world: str) -> int:
        """Drop every session bound to *world*; returns the number removed.

        Used when a world is deleted or purged so its guided sessions stop
        resolving (associated data hidden/cleaned per world-delete spec).
        """
        doomed = [sid for sid, state in self._sessions.items() if state.world == world]
        for sid in doomed:
            del self._sessions[sid]
        return len(doomed)


async def invoke_bounded(provider: Provider | Callable[..., Awaitable[object]], request: GuidedRequest,
                         capabilities: Capabilities | None, cancellation: CancellationToken | None = None,
                         *, compiled_contract_markdown: str | None = None,
                         convergence_specimen_markdown: str | None = None) -> GuidedResponse:
    """Invoke only an admitted provider; no parsed output is committed here.

    ``compiled_contract_markdown`` and ``convergence_specimen_markdown`` are
    ADDITIVE, optional keyword-only hints forwarded to providers that accept
    them (e.g. ``HermesGuidedProvider.invoke``). When both are ``None`` (the
    default) or when the provider does not accept the keywords, the invocation
    behaves exactly as before — no protocol break (R13).
    """
    invalid = request.validate()
    if invalid:
        return GuidedResponse(PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision,
                              Outcome.ERROR, error=invalid)
    if capabilities is None or not capabilities.admitted() or request.deadline_ms > capabilities.max_deadline_ms:
        return GuidedResponse(PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision,
                              Outcome.UNAVAILABLE, error=StructuredError(ErrorCode.CAPABILITY_UNAVAILABLE,
                              "The guided provider is unavailable.", True), retryable=True)
    token = cancellation or CancellationToken()
    if token.cancelled:
        error = StructuredError(ErrorCode.CANCELLED, "The guided request was cancelled.", True)
        return GuidedResponse(PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision, Outcome.ERROR, error=error, retryable=True)
    try:
        hints = {
            name: value
            for name, value in (
                ("compiled_contract_markdown", compiled_contract_markdown),
                ("convergence_specimen_markdown", convergence_specimen_markdown),
            )
            if value is not None
        }
        if hints and hasattr(provider, "invoke"):
            try:
                call = provider.invoke(request, token, **hints)
            except TypeError:
                # Provider does not accept the additive hints; fall back to the
                # two-argument call so non-hint providers keep working — both
                # hints are dropped together (:427-433 semantics, R13).
                call = provider.invoke(request, token)
        else:
            call = provider.invoke(request, token) if hasattr(provider, "invoke") else provider(request, token)
        raw = await asyncio.wait_for(call, request.deadline_ms / 1000)
    except asyncio.TimeoutError:
        token.cancel()
        error = StructuredError(ErrorCode.TIMEOUT, "The guided provider timed out.", True)
        return GuidedResponse(PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision, Outcome.ERROR, error=error, retryable=True)
    except asyncio.CancelledError:
        token.cancel()
        error = StructuredError(ErrorCode.CANCELLED, "The guided request was cancelled.", True)
        return GuidedResponse(PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision, Outcome.ERROR, error=error, retryable=True)
    except (ConnectionError, OSError):
        error = StructuredError(ErrorCode.PROVIDER_UNAVAILABLE, "The guided provider is unavailable.", True)
        return GuidedResponse(PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision, Outcome.UNAVAILABLE, error=error, retryable=True)
    except Exception:
        error = StructuredError(ErrorCode.INTERNAL, "The guided request failed safely.", False)
        return GuidedResponse(PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision, Outcome.ERROR, error=error)
    parsed = GuidedResponse.from_provider(raw, request)
    if parsed is None:
        error = StructuredError(ErrorCode.MALFORMED_OUTPUT, "The provider returned an invalid response.", True)
        return GuidedResponse(PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision, Outcome.ERROR, error=error, retryable=True)
    return parsed


def field_question_text(progress: Mapping[str, Any] | None) -> str:
    """The deterministic question for a plan field (S4 fallback).

    Used when the provider drifts from the field it was told to ask, and when a
    delta is demoted on the fields path: the plan owns the question there.
    """
    progress = progress or {}
    label = str(progress.get("label") or "").strip()
    hint = str(progress.get("hint") or "").strip()
    examples = [str(item).strip() for item in (progress.get("examples") or ()) if str(item).strip()]
    parts: list[str] = []
    if label:
        parts.append(f"{label}.")
    if hint:
        parts.append(hint if hint.endswith(".") else f"{hint}.")
    if examples:
        parts.append("Ejemplos: " + " / ".join(examples) + ".")
    return " ".join(parts).strip() or "Completemos este campo."


def turn_decision_for(
    request: GuidedRequest, response: GuidedResponse,
) -> "TurnDecision | None":
    """The decision a committed question turn records (S2)."""
    if response.outcome is not Outcome.QUESTION or not response.question:
        return None
    revision = request.base_revision + 1
    if request.guided_path == "fields" and request.field_key:
        progress = dict(request.field_progress or {})
        return TurnDecision(
            kind="complete" if progress.get("complete") else "field",
            question=response.question,
            field_key=request.field_key,
            field_label=str(progress.get("label") or "") or None,
            field_progress=progress or None,
            source=(
                "server" if "guided:field-fallback" in response.provenance else "provider"
            ),
            revision=revision,
        )
    return TurnDecision(
        kind="free", question=response.question, source="provider", revision=revision,
    )


async def continue_session(store: GuidedSessionStore, provider: Provider | Callable[..., Awaitable[object]],
                           request: GuidedRequest, capabilities: Capabilities | None,
                           cancellation: CancellationToken | None = None,
                           *, compiled_contract_markdown: str | None = None,
                           convergence_specimen_markdown: str | None = None) -> tuple[GuidedResponse, SessionState | None]:
    state = store.recover(request.session_id, request.authorization_binding)
    if state is None:
        error = StructuredError(ErrorCode.UNAUTHORIZED, "The session is unavailable.", False)
        return GuidedResponse(PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision, Outcome.ERROR, error=error), None
    if state.phase == "complete":
        error = StructuredError(ErrorCode.INVALID_INPUT, "The guided session is complete.", False)
        return GuidedResponse(PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision, Outcome.ERROR, error=error), None
    if state.revision != request.base_revision:
        error = StructuredError(ErrorCode.REVISION_CONFLICT, "The session revision is stale.", True)
        return GuidedResponse(PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision, Outcome.ERROR, error=error, retryable=True), None
    response = await invoke_bounded(provider, request, capabilities, cancellation,
                                    compiled_contract_markdown=compiled_contract_markdown,
                                    convergence_specimen_markdown=convergence_specimen_markdown)
    if response.outcome in {Outcome.ERROR, Outcome.UNAVAILABLE}:
        return response, None
    if (
        request.guided_path == "fields" and request.field_key
        and response.outcome is Outcome.QUESTION
        and response.field_key != request.field_key
    ):
        # S4: the provider may not change the subject on the questionnaire. Its
        # extraction still counts; only the question text is the server's.
        logger.warning(
            "guided provider drifted from the field it was told to ask "
            "(asked=%s, request=%s, revision=%s)",
            response.field_key, request.field_key, request.base_revision,
        )
        response = GuidedResponse(
            PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision,
            response.outcome,
            provenance=(*response.provenance, "guided:field-fallback"),
            question=field_question_text(request.field_progress),
            provider_run_id=response.provider_run_id,
            synthesis=response.synthesis,
            answer=response.answer,
            intent=response.intent,
            field_key=request.field_key,
            # The extraction is the author's data: drifting never costs a fact.
            observations=response.observations,
        )
    if response.intent == EXPLORE_INTENT and response.outcome is Outcome.QUESTION:
        # World exploration inside the questionnaire (S1/S3): the author asked
        # about the world instead of answering the current field. The turn
        # answers and keeps asking the same field, so nothing may settle: the
        # delta is dropped and any observation a questionnaire field claims is
        # discarded. World facts outside the plan stay as context.
        from guided_character_domain import plan_scoped_observations, resolve_candidate_nivel

        profile = session_flow_profile(state)
        response = GuidedResponse(
            PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision,
            response.outcome,
            provenance=(*response.provenance, "guided:explore"),
            question=response.question,
            delta=None,
            provider_run_id=response.provider_run_id,
            synthesis=response.synthesis,
            answer=response.answer,
            intent=response.intent,
            observations=plan_scoped_observations(
                response.observations or {},
                entity_type=profile.entity_type if profile is not None else None,
                nivel=resolve_candidate_nivel(state.candidate),
            ) or None,
        )
    if response.outcome is Outcome.DELTA:
        # Server-authoritative completeness gate: a provider delta is never a
        # trusted completeness claim. In full guided mode, an incomplete candidate
        # must not be exposed as a proposal; keep asking exactly one focused
        # question per turn until the minimum required identity data is present.
        # Fast mode proceeds with marked assumptions and skips the gate.
        from guided_character_domain import candidate_minimum_complete, next_required_question
        profile = session_flow_profile(state)
        if not candidate_minimum_complete(
            state.candidate, delta=response.delta, mode=request.guided_mode,
            groups=profile.minimum_groups if profile is not None else None,
        ):
            if request.guided_path == "fields" and request.field_progress:
                # S3: on the questionnaire the plan owns the next question; the
                # anchor gate keeps only "can this become a proposal?".
                question = field_question_text(request.field_progress)
            else:
                question = next_required_question(
                    state.candidate, delta=response.delta,
                    groups=profile.minimum_groups if profile is not None else None,
                    question_keys=profile.question_keys if profile is not None else None,
                    ui_copy_key=profile.ui_copy_key if profile is not None else None,
                )
            # Demoting a delta must not throw the author's data away. The fields
            # move to the internal observations partition (read back into
            # known_state and into the gate, never a public proposal) and the
            # provider's synthesis stays on the message so the author still sees
            # the summary above the question.
            preserved = dict(response.observations or {})
            if response.delta:
                preserved.update(response.delta)
            response = GuidedResponse(
                PROTOCOL_VERSION, request.request_id, request.session_id, request.base_revision,
                Outcome.QUESTION,
                provenance=(
                    (*response.provenance, "guided:field-fallback")
                    if request.guided_path == "fields" and request.field_progress
                    else response.provenance
                ),
                question=question,
                provider_run_id=response.provider_run_id,
                synthesis=response.synthesis,
                observations=preserved or None,
            )
    return response, store.commit(request, response, turn_decision_for(request, response))

"""Readiness probes and honest card projection for the Configuration Center.

``local_editor`` readiness is proven by a real local storage round-trip:
write a probe payload, read it back, verify byte-identity, then delete it.
The result is derived runtime truth — configuration or registry state alone
never proves readiness. It never overstates a remote/cloud capability.

``project_cards`` derives the OC12 card states from authoritative local
truth (ONB-3.1/3.2, OC11/OC12/OC21):

- Cloud cards WITHOUT a dedicated contract NEVER become ``configured`` from
  local evidence: only their dedicated contracts may mark them configured. A
  stale registry claim is downgraded to ``pending`` instead of being trusted.
  The ``backup`` card is no longer in that set: it gained a DEDICATED CONTRACT
  (REQ-CC-1) and is ``configured`` only with a persisted folder AND a recorded
  successful local write, supplied through ``backup_state``.
- The identity card HAS a dedicated contract (vault-settings-configure,
  R-ID-01): it is ``configured`` ONLY when the persisted vault flag is on
  (``capabilities.vault.enabled``) OR when ``DEMIURGOS_AUTH_MODE=credentials``
  is active; an account alone never configures it (S-ID-01b) and a registry
  claim never configures it.
- The telegram card HAS a dedicated contract (ONB-3.3 backend): its state is
  supplied by the backend from real evidence (write-only token presence plus
  the last Telegram API connection-test outcome), never from a bare registry
  claim. ``project_cards`` accepts that derived state via ``telegram_state``
  and defaults to ``pending`` when absent.
- The assistant card is ``configured`` ONLY when the registry records the
  three-proof evidence (text + vision probes passed and Hermes runtime
  acceptance). A bare ``capabilities.assistant == "configured"`` claim is
  never proof.
- ``world`` follows filesystem truth (a real world directory exists),
  ``locale`` follows the persisted step-0 locale, and ``offline`` follows
  the local-storage probe.
"""

from __future__ import annotations

import os
import uuid
from pathlib import Path
from typing import Any, Mapping, Sequence

from local_state import CARD_STATES


# Cloud/remote capabilities without a dedicated contract: their cards can
# never be derived to ``configured`` from local evidence in this slice
# (ONB-3.1). The constant is KEPT (``project_cards`` iterates it) but is now
# EMPTY: ``backup`` left it in WU-14, because the modern backup/restore flow
# gained a dedicated contract (REQ-CC-1, SC-CC-1.3) supplied via
# ``backup_state``. A future cloud card without a contract goes back in here.
CLOUD_CARDS: frozenset[str] = frozenset()

# Assistant proof evidence keys required before the card may be configured.
ASSISTANT_PROOF_KEYS: tuple[str, ...] = ("text", "vision", "runtime")
ASSISTANT_PROOF_VALUES: Mapping[str, str] = {
    "text": "passed",
    "vision": "passed",
    "runtime": "accepted",
}


def assistant_proven(state: Mapping[str, Any]) -> bool:
    """True only when all three proofs are recorded in the registry.

    The registry must hold ``assistant_acceptance`` with the exact outcome
    values from the three-proof gate (ONB-2.5): text=passed, vision=passed,
    runtime=accepted. Anything else — including a bare capability claim —
    is not proof.
    """
    evidence = state.get("assistant_acceptance")
    if not isinstance(evidence, Mapping):
        return False
    return all(
        evidence.get(key) == expected
        for key, expected in ASSISTANT_PROOF_VALUES.items()
    )


def identity_configured(state: Mapping[str, Any] | None = None) -> bool:
    """Dedicated identity contract (R-ID-01, S-ID-01a/b).

    The identity card is ``configured`` when the persisted vault flag is ON
    (``capabilities.vault.enabled`` — PRIMARY, S-ID-01a) OR when the
    credentials auth mode is active (``DEMIURGOS_AUTH_MODE=credentials`` —
    operator override). An account alone NEVER configures identity: without
    the flag (or the env override) the card stays ``pending`` even when a
    local account exists (S-ID-01b). Registry capability claims never
    configure identity.
    """
    mode = os.environ.get("DEMIURGOS_AUTH_MODE", "").strip().lower()
    if mode == "credentials":
        return True
    if state is None:
        return False
    capabilities = state.get("capabilities")
    vault = capabilities.get("vault") if isinstance(capabilities, Mapping) else None
    if isinstance(vault, Mapping) and vault.get("enabled"):
        return True
    return False


def project_cards(
    state: Mapping[str, Any],
    worlds: Sequence[str],
    probe_ok: bool,
    telegram_state: str | None = None,
    backup_state: str | None = None,
) -> dict[str, str]:
    """Derive honest Configuration Center card states (OC11/OC12/OC21).

    ``state`` is the local registry snapshot; ``worlds`` is the runtime list
    of existing world names (filesystem truth); ``probe_ok`` is the derived
    local-storage probe result; ``telegram_state`` is the state supplied by
    the ONB-3.3 telegram backend (write-only token presence + last connection
    test) or None when no backend evidence exists. ``backup_state`` is the
    backup card's dedicated-contract state (REQ-CC-1), supplied by
    ``backup.state.backup_state`` from a persisted folder plus a recorded
    successful local write; without it the card stays ``pending``. Returns one
    CardState per card key.
    """
    cards: dict[str, str] = {}
    for key in CLOUD_CARDS:
        cards[key] = "pending"
    # Identity HAS a dedicated contract (vault-settings-configure, R-ID-01): the
    # card follows the live vault flag + credentials mode, never a registry
    # claim and never the account alone (S-ID-01b).
    cards["identity"] = "configured" if identity_configured(state) else "pending"
    # The importer has no dedicated contract in this change (ONB-3.5): its
    # card exposes entry/pending only and can never be derived to configured
    # from local evidence. The dedicated importer SDD owns completion.
    cards["import"] = "pending"
    # Telegram has a dedicated backend contract (ONB-3.3): its card follows
    # the backend's real evidence; without it the card stays pending.
    cards["telegram"] = (
        telegram_state if telegram_state in CARD_STATES else "pending"
    )
    # Backup has its own dedicated contract (REQ-CC-1): the backend derives it
    # from a persisted folder AND a recorded successful local write, exactly
    # like telegram. A bare registry claim is never consulted, so the card
    # stays pending without that evidence (SC-CC-1.1/1.2).
    cards["backup"] = (
        backup_state if backup_state in CARD_STATES else "pending"
    )
    cards["assistant"] = "configured" if assistant_proven(state) else "pending"
    cards["world"] = "configured" if worlds else "pending"
    cards["locale"] = "configured" if state.get("locale") else "pending"
    cards["offline"] = "configured" if probe_ok else "error"
    return cards


def probe_local_storage(root: Path) -> dict[str, Any]:
    """Round-trip probe: write → read → verify → delete.

    Returns ``{"probe": "local_editor", "ok": bool, "detail": str}``. The probe
    file lives under ``<root>/data/probes/`` and is always removed afterwards.
    """
    probe_dir = Path(root) / "data" / "probes"
    payload = f"demiurgos-local-editor-probe-{uuid.uuid4().hex}\n"
    probe = probe_dir / f"local-editor-{uuid.uuid4().hex}.probe"
    try:
        probe_dir.mkdir(parents=True, exist_ok=True)
        probe.write_text(payload, encoding="utf-8")
        read_back = probe.read_text(encoding="utf-8")
        if read_back != payload:
            return {
                "probe": "local_editor",
                "ok": False,
                "detail": "read-back mismatch",
            }
        return {
            "probe": "local_editor",
            "ok": True,
            "detail": "storage round-trip ok",
        }
    except OSError as exc:
        return {"probe": "local_editor", "ok": False, "detail": str(exc)}
    finally:
        try:
            probe.unlink(missing_ok=True)
        except OSError:
            pass


def local_editor_ready(root: Path) -> bool:
    """Derived essential badge: true only when the probe round-trips."""
    return bool(probe_local_storage(root).get("ok"))
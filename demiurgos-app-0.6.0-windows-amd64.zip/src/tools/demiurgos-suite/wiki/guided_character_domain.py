"""Domain rules for guided creation of a new character.

This module is deliberately diskless. It turns provider deltas into explicit
candidate state, reads graph evidence in a fixed order, and emits a validated
Markdown proposal without persisting it.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import PurePosixPath
from typing import Any, Mapping, Protocol

import yaml

from guided_character_body import render_character_body
from guided_character_protocol import CandidateState, MessageType, SessionState, TypedMessage
from demiurgos_language import normalize_language, resolve_domain_language


_SLUG = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_NEW_CHARACTER_TERMS = (
    "character", "personaje", "protagonist", "protagonista", "villain", "villano",
    "warrior", "guerrero", "brother", "sister", "hermano", "hermana", "character",
    "wife", "spouse", "husband", "partner", "esposa", "cónyuge", "esposo", "pareja",
)
_NEW_CHARACTER_VERBS = ("create", "crear", "write", "escribir", "invent", "inventar", "need", "necesito", "want", "quiero", "design", "diseñar", "make", "hacer")
_EDIT_CHARACTER_TERMS = ("edit", "editar", "existing", "existente", "modify", "modificar", "update", "actualizar", "change", "cambiar")
_RELATED_REFERENCE_PATTERN = re.compile(
    r"\b(?:[a-záéíóúñ]+(?:\s+[a-záéíóúñ]+){0,3})\s+(?:of|de)\s+"
    r"([A-ZÁÉÍÓÚÑ][\wÁÉÍÓÚÑáéíóúñ'’-]*(?:\s+[A-ZÁÉÍÓÚÑ][\wÁÉÍÓÚÑáéíóúñ'’-]*){0,2})"
    r"|\b([A-ZÁÉÍÓÚÑ][\wÁÉÍÓÚÑáéíóúñ'’-]*(?:\s+[A-ZÁÉÍÓÚÑ][\wÁÉÍÓÚÑáéíóúñ'’-]*){0,2})['’]s\s+"
    r"(?:the\s+)?[a-záéíóúñ]+(?:\s+[a-záéíóúñ]+){0,3}\b",
)
_FAST_MODE_MARKERS = (
    "immediate", "immediately", "right now", "rápidamente", "rapidamente", "inmediatamente", "ahora mismo",
    "fundamental", "fundamentals", "lo básico", "lo basico", "only basics", "solo lo fundamental",
    "skip the questionnaire", "skip questionnaire", "sin cuestionario", "omitir cuestionario",
    "write it now", "escríbelo ya", "escribelo ya", "create it now", "créalo ya", "crealo ya",
    "just create it", "just write it", "sin preguntas", "no me hagas preguntas", "without questions",
    "no questions",
)
_FAST_QUICK_MARKERS = ("fast", "quick", "quickly", "rápido", "rapido")
_FAST_DIRECT_VERBS = ("create", "crear", "write", "escribir", "make", "hacer", "haz", "quiero", "want")

_RELATION_TERM_TO_KEY: dict[str, str] = {
    "brother": "brother", "sister": "sister", "wife": "wife", "husband": "husband",
    "spouse": "spouse", "partner": "partner", "cousin": "cousin",
    "grandfather": "grandfather", "grandmother": "grandmother",
    "uncle": "uncle", "aunt": "aunt", "nephew": "nephew", "niece": "niece",
    "mentor": "mentor",
    "hermano": "brother", "hermana": "brother",
    "esposa": "wife", "esposo": "husband",
    "cónyuge": "spouse", "conyuge": "spouse", "pareja": "partner",
    "primo": "cousin", "prima": "cousin",
    "abuelo": "grandfather", "abuela": "grandmother",
    "tío": "uncle", "tio": "uncle", "tía": "aunt", "tia": "aunt",
    "sobrino": "nephew", "sobrina": "niece",
    "mentora": "mentor",
}
_RELATION_ES_LABELS: dict[str, str] = {
    "brother": "hermano", "sister": "hermana", "wife": "esposa", "husband": "esposo",
    "spouse": "cónyuge", "partner": "pareja", "cousin": "primo",
    "grandfather": "abuelo", "grandmother": "abuela", "uncle": "tío", "aunt": "tía",
    "nephew": "sobrino", "niece": "sobrina", "mentor": "mentor/mentora",
}
_SPANISH_RELATION_TERMS = frozenset({
    "hermano", "hermana", "esposa", "esposo", "cónyuge", "conyuge", "pareja",
    "primo", "prima", "abuelo", "abuela", "tío", "tio", "tía", "tia",
    "sobrino", "sobrina", "mentora",
})
_RELATION_GOAL_BUDGET = 400

# Server-owned minimum identity data that must be present in a candidate before
# a provider delta may be promoted to a proposal in full guided mode. These are
# the essential identity anchors of the v1 character contract: an identity
# (name) and a defining desire. Fast mode proceeds with marked assumptions.
MINIMUM_IDENTITY_FIELDS = ("name", "nombre", "title")
MINIMUM_DESIRE_FIELDS = ("desire", "deseo", "motivacion", "motivations", "motivation", "motivaciones")


def _candidate_known_fields(candidate: CandidateState, delta: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Every fact the session already holds, whatever partition it lives in.

    The provider keeps what it collects in ``observations`` (they are internal
    notes, never public proposals). The completeness gate must read them too, or
    a session that already knows the character's name keeps being asked for it.
    Canon and proposals win over observations when a key exists in both.
    """
    known = dict(candidate.accepted_canon)
    known.update(candidate.proposals)
    if delta:
        known.update(delta)
    # A name may be stored once, as a nested identity record
    # (``identidad: {value: {nombre: …}}``); the gate must see it.
    for key in ("identidad", "identity"):
        record = known.get(key)
        value = record.get("value", record) if isinstance(record, Mapping) else record
        if isinstance(value, Mapping):
            for inner in ("name", "nombre", "title"):
                if inner in value:
                    known.setdefault(inner, value[inner])
    observations = getattr(candidate, "observations", None)
    if isinstance(observations, Mapping):
        for key, value in observations.items():
            known.setdefault(key, value)
    return known


def candidate_minimum_complete(
    candidate: CandidateState, *,
    delta: Mapping[str, Any] | None = None,
    mode: str = "full",
    groups: tuple[frozenset[str], ...] | None = None,
) -> bool:
    """Server-authoritative minimum completeness gate for guided creation.

    A provider delta is never a trusted completeness claim: only the candidate
    data the server actually holds decides readiness. A candidate is minimally
    complete when every required group has at least one present field. The
    groups come from the resolved flow profile (``prompt_minimums_for``); the
    default keeps the character contract byte-identically. Fast mode proceeds
    with marked assumptions and skips the gate.
    """
    if mode == "fast":
        return True
    known = _candidate_known_fields(candidate, delta)
    required = groups if groups is not None else (
        MINIMUM_IDENTITY_FIELDS, MINIMUM_DESIRE_FIELDS,
    )
    return all(any(key in known for key in group) for group in required)


# Free-form nivel probes (D4): there is no structured nivel field on the
# candidate; the narrative-density label is read from these known-field keys,
# first string hit wins.
_NIVEL_PROBES = ("nivel", "nivel_narrativo", "rol_narrativo", "nivel narrativo", "rol narrativo")


def has_finished_exchange(state: SessionState) -> bool:
    """True once a provider-committed exchange has finished (D3).

    A finished exchange is a provider-committed typed message: a committed
    QUESTION (``ASSISTANT_RESPONSE`` carrying the ``"question"`` key) or a
    committed DELTA (``PROPOSAL``). Server-authored messages — e.g. the
    ``{"text": …}`` copies written by ``begin_confirmation`` /
    ``resolve_confirmation`` without any provider run — are excluded by shape,
    so the finished-exchange conjunct can never be satisfied by a
    confirmation script (R10).
    """
    return any(
        message.message_type is MessageType.PROPOSAL
        or (
            message.message_type is MessageType.ASSISTANT_RESPONSE
            and "question" in message.content
        )
        for message in state.messages
    )


def _probe_text(value: Any) -> str | None:
    """Read a free-form probe value, unwrapping the stored ``{"value": …}``."""
    if isinstance(value, Mapping) and "value" in value:
        return _probe_text(value["value"])
    return value if isinstance(value, str) else None


def resolve_candidate_nivel(candidate: CandidateState) -> str:
    """Resolve the candidate's narrative-density label (1º/2º/3º; D4).

    Probes the free-form known fields in a fixed order (first string hit
    wins) and normalizes: ``"2"``/``"secund"`` → 2º, ``"3"``/``"rellen"`` →
    3º, anything else or missing → 1º (locked fallback: an unknown nivel is
    treated as the principal exemplar, R11). Stored records
    (``{"value": …}``) are unwrapped so a real provider delta resolves too.
    """
    known = _candidate_known_fields(candidate)
    for probe in _NIVEL_PROBES:
        value = _probe_text(known.get(probe))
        if value is not None:
            text = value.casefold()
            if "2" in text or "secund" in text:
                return "2º"
            if "3" in text or "rellen" in text:
                return "3º"
            return "1º"
    return "1º"


def _identity_question(language: str) -> str:
    if language == "en":
        return "What is this character's name?"
    return "¿Cómo se llama este personaje?"


_QUESTION_COPY: dict[str, tuple[str, str]] = {
    # key: (Spanish, English)
    "desire": (
        "¿Cuál es el deseo que define a este personaje?",
        "What is the character's defining desire?",
    ),
    "origin": (
        "¿De dónde vienen las reglas de este sistema? Puede ser un dios, la "
        "biología, una institución, la tecnología o la propia naturaleza.",
        "Where do this system's rules come from? A god, biology, an "
        "institution, technology, or nature itself.",
    ),
    "limit": (
        "¿Qué no puede hacer este sistema y cuándo falla?",
        "What can this system not do, and when does it fail?",
    ),
    "event": (
        "¿Qué suceso o era quieres registrar en la cronología?",
        "Which event or era do you want to record in the chronology?",
    ),
    "entity_class": (
        "¿Qué clase de entidad es? Un lugar, una facción, una criatura, un "
        "artefacto, una cultura o una especie.",
        "What kind of entity is it? A place, a faction, a creature, an "
        "artifact, a culture, or a species.",
    ),
}


_IDENTITY_COPY_BY_FLOW: dict[str, tuple[str, str]] = {
    # copy key: (Spanish, English)
    "character": ("¿Cómo se llama este personaje?", "What is this character's name?"),
    "system": ("¿Cómo se llama este sistema?", "What is this system called?"),
    "chronology": (
        "¿Cómo se llama este suceso o era?",
        "What is this event or era called?",
    ),
    "entity": (
        "¿Cómo se llama esta entidad?",
        "What is this entity called?",
    ),
}


def _question_for(key: str, language: str, ui_copy_key: str | None = None) -> str:
    if key == "identity":
        copy = _IDENTITY_COPY_BY_FLOW.get(ui_copy_key or "character")
        if copy is None:
            return _identity_question(language)
        return copy[1] if language == "en" else copy[0]
    copy = _QUESTION_COPY.get(key)
    if copy is None:
        return (
            "¿Qué dato falta para completar esta entidad?"
            if language != "en" else "Which required detail is still missing?"
        )
    return copy[1] if language == "en" else copy[0]


def next_required_question(
    candidate: CandidateState, *,
    delta: Mapping[str, Any] | None = None,
    language: str | None = None,
    question_keys: tuple[str, ...] | None = None,
    groups: tuple[frozenset[str], ...] | None = None,
    ui_copy_key: str | None = None,
) -> str:
    """One server-owned focused question for the first missing required field.

    Walks the flow's required groups in order and asks the first unsatisfied
    one, in the configured UI language. Never a questionnaire: exactly one
    question. The character defaults preserve the existing copy verbatim.
    """
    known = _candidate_known_fields(candidate, delta)
    lang = normalize_language(language or resolve_domain_language("conversation"))
    keys = question_keys or ("identity", "desire")
    required = groups if groups is not None else (
        MINIMUM_IDENTITY_FIELDS, MINIMUM_DESIRE_FIELDS,
    )
    for index, group in enumerate(required):
        if any(key in known for key in group):
            continue
        key = keys[index] if index < len(keys) else "identity"
        return _question_for(key, lang, ui_copy_key)
    # All groups satisfied: repeat the last focused prompt rather than inventing
    # a new question shape.
    return _question_for(keys[-1] if keys else "identity", lang, ui_copy_key)


def _default_question(language: str, short: bool) -> tuple[str, str]:
    """Default guided question/response in the configured UI language."""
    if language == "en":
        return (
            "What is the character's defining desire?",
            "Let's define the character one step at a time.",
        ) if short else (
            "What should this character want most?",
            "I can help shape this new character.",
        )
    return (
        "¿Cuál es el deseo que define a este personaje?",
        "Definamos el personaje paso a paso.",
    ) if short else (
        "¿Qué debería querer este personaje por encima de todo?",
        "Puedo ayudar a dar forma a este nuevo personaje.",
    )


@dataclass(frozen=True)
class GuidedTurn:
    """Compact routing result; provider-facing details stay out of the reply."""

    is_new_character: bool
    question: str | None = None
    response: str = ""
    requires_confirmation: bool = False
    mode: str = "full"
    depth: str = "standard"

    @property
    def is_new_entity(self) -> bool:
        """Flow-neutral alias; the field name is kept for character callers."""
        return self.is_new_character


def route_new_character_intent(author_input: str, *, allow_descriptive_seed: bool = False,
                               language: str | None = None) -> GuidedTurn:
    """Admit new-character intent and ask at most one question."""
    words = set(re.findall(r"[a-záéíóúñ]+", author_input.lower()))
    if words & set(_EDIT_CHARACTER_TERMS):
        return GuidedTurn(False)
    related_reference = named_reference_name(author_input) is not None
    related_creation = related_reference and bool(words & set(_NEW_CHARACTER_VERBS))
    is_new = related_creation or (bool(words & set(_NEW_CHARACTER_TERMS)) and (
        allow_descriptive_seed or bool(words & set(_NEW_CHARACTER_VERBS))
    ))
    if not is_new:
        return GuidedTurn(False)
    lowered_input = author_input.casefold()
    fast_mode = any(
        re.search(rf"\b{re.escape(marker)}\b", lowered_input)
        for marker in _FAST_MODE_MARKERS
    )
    if not fast_mode and any(re.search(rf"\b{re.escape(marker)}\b", lowered_input) for marker in _FAST_QUICK_MARKERS):
        fast_mode = any(
            re.search(rf"\b{re.escape(verb)}\b.{{0,32}}\b(?:fast|quick|quickly|rápido|rapido)\b", lowered_input)
            for verb in _FAST_DIRECT_VERBS
        )
    mode = "fast" if fast_mode else "full"
    depth = "fundamental" if fast_mode else "standard"
    question, response = _default_question(language or resolve_domain_language("conversation"), len(words) <= 4)
    return GuidedTurn(
        True, question, response, related_creation, mode, depth,
    )


def route_guided_intent(
    author_input: str,
    profile,
    *,
    allow_descriptive_seed: bool = False,
    language: str | None = None,
) -> GuidedTurn:
    """Route new-entity intent for the session's flow (S3).

    The character flow keeps its historical matcher byte-identically. Every
    other flow uses the declaration's bounded intent vocabulary (terms and
    verbs) supplied by the published skill; no flow-specific branch lives here.
    """
    if getattr(profile, "intent_matcher", "declarative") == "legacy-character":
        return route_new_character_intent(
            author_input,
            allow_descriptive_seed=allow_descriptive_seed,
            language=language,
        )
    lowered = author_input.casefold()
    words = set(re.findall(r"[a-záéíóúñ]+", lowered))
    if words & set(_EDIT_CHARACTER_TERMS):
        return GuidedTurn(False)
    terms = tuple(getattr(profile, "intent_terms", ()) or ())
    verbs = tuple(getattr(profile, "intent_verbs", ()) or ())
    if not terms or not verbs:
        return GuidedTurn(False)
    has_term = any(
        re.search(rf"\b{re.escape(term.casefold())}\b", lowered) for term in terms
    )
    has_verb = any(
        re.search(rf"\b{re.escape(verb.casefold())}\b", lowered) for verb in verbs
    )
    if not (has_term and has_verb):
        return GuidedTurn(False)
    return GuidedTurn(True, None, "", False, "full", "standard")


def confirmation_decision(author_input: str) -> bool | None:
    """Classify only unambiguous confirmation answers; fail closed otherwise."""
    words = set(re.findall(r"[a-záéíóúñ]+", author_input.lower()))
    affirmative = {"yes", "y", "si", "sí", "sure", "ok", "okay", "adelante", "confirmo", "acepto", "start", "empezar"}
    negative = {"no", "n", "cancel", "cancelar", "later", "después", "despues", "stop", "detener"}
    if words & affirmative and not words & negative:
        return True
    if words & negative and not words & affirmative:
        return False
    return None


@dataclass(frozen=True)
class Evidence:
    value: Any
    certainty: str
    provenance: tuple[str, ...]


def _record(value: Any, certainty: str, provenance: tuple[str, ...]) -> dict[str, Any]:
    return {"value": value, "certainty": certainty, "provenance": list(provenance)}


def apply_delta(candidate: CandidateState, delta: Mapping[str, Any], provenance: tuple[str, ...] = ()) -> CandidateState:
    """Apply provider data to non-canon partitions only."""
    for key, value in delta.items():
        # A provider cannot address accepted_canon, even if it supplies that
        # field name; acceptance is exclusively an author transition.
        target = getattr(candidate, key, None) if key != "accepted_canon" else None
        if isinstance(target, dict):
            target[key] = _record(value, "proposed", provenance)
        elif isinstance(target, list):
            target.append(_record(value, "proposed", provenance))
        else:
            candidate.proposals[key] = _record(value, "proposed", provenance)
    candidate.provenance.extend(provenance)
    return candidate


def accept_proposal(candidate: CandidateState, key: str) -> Any:
    """Move one proposal to canon; no implicit acceptance of other values."""
    if key not in candidate.proposals:
        raise KeyError(key)
    item = candidate.proposals.pop(key)
    if isinstance(item, Mapping) and "value" in item:
        accepted = dict(item)
        accepted["certainty"] = "accepted"
        candidate.accepted_canon[key] = accepted
        return accepted
    candidate.accepted_canon[key] = _record(item, "accepted", ())
    return candidate.accepted_canon[key]


def reject_proposal(candidate: CandidateState, key: str) -> Any:
    """Remove one proposal while retaining a rejection record outside canon."""
    if key not in candidate.proposals:
        raise KeyError(key)
    item = candidate.proposals.pop(key)
    candidate.provenance.append(f"rejected:{key}")
    return item


class GraphReader(Protocol):
    def search(self, query: str) -> list[Mapping[str, Any]]: ...
    def read(self, entity_path: str) -> Mapping[str, Any] | None: ...
    def links(self, entity_path: str, kind: str) -> list[Mapping[str, Any]]: ...


@dataclass
class GraphEvidence:
    matches: list[Mapping[str, Any]] = field(default_factory=list)
    entity: Mapping[str, Any] | None = None
    forward: list[Mapping[str, Any]] = field(default_factory=list)
    backlinks: list[Mapping[str, Any]] = field(default_factory=list)
    unresolved: bool = False
    provenance: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class NamedReference:
    """Bounded result of resolving a named entity for a related character."""

    name: str
    context: str = ""
    unresolved: bool = False
    ambiguous: bool = False


def named_reference_name(author_input: str) -> str | None:
    match = _RELATED_REFERENCE_PATTERN.search(author_input)
    if not match:
        return None
    return next((group.strip() for group in match.groups() if group), None)


@dataclass(frozen=True)
class RelatedGoal:
    """Safe, structured relational objective for a new character."""

    relation: str | None
    reference_name: str | None
    summary: str


def _detect_relation(author_input: str) -> tuple[str, str] | None:
    """Return ``(canonical_key, matched_term)`` only for a single safe relation."""
    lowered = author_input.casefold()
    matches: list[tuple[str, str]] = []
    for term, key in _RELATION_TERM_TO_KEY.items():
        if re.search(rf"\b{re.escape(term)}\b", lowered):
            matches.append((key, term))
    unique_keys = {key for key, _ in matches}
    if len(unique_keys) != 1:
        return None
    return unique_keys.pop(), matches[0][1]


def _relation_goal_text(relation_key: str, matched_term: str, reference: str, language: str) -> str:
    if language == "es":
        label = matched_term if matched_term in _SPANISH_RELATION_TERMS else _RELATION_ES_LABELS.get(relation_key, relation_key)
        return f"Nuevo personaje: {label} de {reference}"
    return f"New character: {relation_key} of {reference}"


def extract_related_goal(author_input: str, *, reference_name: str | None = None,
                         language: str | None = None) -> RelatedGoal:
    """Extract a safe relational goal without ever inventing one.

    Returns a bounded, localized summary of the requested relationship and its
    reference character.  When no single relation can be detected safely, the
    goal is empty and the original author request remains the only preserved
    intent; nothing is fabricated.
    """
    reference = reference_name or named_reference_name(author_input)
    detected = _detect_relation(author_input)
    if detected is None or not reference:
        return RelatedGoal(None, reference, "")
    relation_key, matched_term = detected
    lang = normalize_language(language or resolve_domain_language("conversation"))
    return RelatedGoal(
        relation_key,
        reference,
        _relation_goal_text(relation_key, matched_term, reference, lang)[:_RELATION_GOAL_BUDGET],
    )


def _graph_value(item: Mapping[str, Any] | Any, key: str, default: Any = "") -> Any:
    if isinstance(item, Mapping):
        return item.get(key, default)
    return getattr(item, key, default)


def _is_canonical_character(item: Mapping[str, Any] | Any) -> bool:
    entity_type = str(_graph_value(item, "type")).casefold()
    path = str(_graph_value(item, "path")).replace("\\", "/").casefold()
    return entity_type in {"personaje", "character"} or (
        not entity_type and path.startswith("personajes/")
    )


def resolve_named_reference(graph: GraphReader, author_input: str) -> NamedReference | None:
    """Resolve only an explicit related-entity name through search then read."""
    name = named_reference_name(author_input)
    if name is None:
        return None
    matches = list(graph.search(name))
    canonical = [item for item in matches if _is_canonical_character(item)]
    exact = [item for item in canonical if str(_graph_value(item, "name")).casefold() == name.casefold()]
    if not exact:
        exact = [
            item for item in canonical
            if str(_graph_value(item, "name")).casefold().startswith(name.casefold())
        ]
    if len(exact) != 1:
        return NamedReference(name, unresolved=True, ambiguous=bool(matches))

    path = _graph_value(exact[0], "path")
    if not isinstance(path, str) or not path:
        return NamedReference(name, unresolved=True)
    entity = graph.read(path)
    if entity is None:
        return NamedReference(name, unresolved=True)

    # Relationship links are relevant for a request that explicitly asks for a sibling.
    forward = list(graph.links(path, "forward"))
    backlinks = list(graph.links(path, "backlinks"))
    lines = [f"Verified reference: {str(_graph_value(entity, 'name', name))}"]
    for label, key in (("Type", "type"), ("Title", "title"), ("Description", "description")):
        value = _graph_value(entity, key)
        if isinstance(value, str) and value.strip():
            lines.append(f"{label}: {value.strip()}")
    content = _graph_value(entity, "content")
    if isinstance(content, str) and content.strip():
        lines.append(f"Facts:\n{content[:3_000].strip()}")
    related_names = [
        str(_graph_value(item, "name"))
        for item in (*forward, *backlinks)
        if str(_graph_value(item, "name")).strip()
    ]
    if related_names:
        lines.append("Verified graph relationships: " + ", ".join(dict.fromkeys(related_names)))
    return NamedReference(name, "\n".join(lines)[:4_000])


def collect_graph_evidence(graph: GraphReader, query: str, relationships: bool = True) -> GraphEvidence:
    """Use search -> read -> links/backlinks, preserving missing evidence."""
    matches = list(graph.search(query))
    if not matches:
        return GraphEvidence(unresolved=True, provenance=[f"graph:search:{query}"])
    path = matches[0].get("path")
    if not isinstance(path, str) or not path:
        return GraphEvidence(matches=matches, unresolved=True, provenance=[f"graph:search:{query}"])
    entity = graph.read(path)
    provenance = [f"graph:search:{query}", f"graph:read:{path}"]
    if entity is None:
        return GraphEvidence(matches, unresolved=True, provenance=provenance)
    forward: list[Mapping[str, Any]] = []
    backlinks: list[Mapping[str, Any]] = []
    if relationships:
        forward = list(graph.links(path, "forward"))
        backlinks = list(graph.links(path, "backlinks"))
        provenance.extend((f"graph:links:forward:{path}", f"graph:links:backlinks:{path}"))
    return GraphEvidence(matches, entity, forward, backlinks, False, provenance)


def retain_graph_evidence(candidate: CandidateState, evidence: GraphEvidence, conflict: Any = None) -> None:
    """Retain unresolved and conflicting evidence instead of resolving it."""
    candidate.provenance.extend(evidence.provenance)
    if evidence.unresolved:
        candidate.unresolved_references.append(_record(evidence.matches, "unknown", tuple(evidence.provenance)))
    if conflict is not None:
        candidate.conflicts.append(_record(conflict, "conflicted", tuple(evidence.provenance)))


class FichaValidationError(ValueError):
    pass


@dataclass(frozen=True)
class FichaProposal:
    target: str
    content: str
    digest_basis: str


def serialize_entity(
    candidate: CandidateState, *,
    world: str, slug: str, title: str,
    entity_type: str, target_section: str, type_label: str,
    provenance_default: str = "guided-character-v1",
    frontmatter_fields: tuple[str, ...] = (),
    existing_targets: set[str] | None = None,
) -> FichaProposal:
    """Serialize an additive OKF v1 entity and validate its authorized target.

    The flow profile supplies the kernel-owned section and type label. Every
    non-character flow keeps the shared YAML body shape unchanged; the character
    flow renders its body from the pinned narrative-level specimen instead
    (structure and labels only, accents intact, no duplicated Identity/Canon
    Anchors sections).
    """
    if not world.strip() or not _SLUG.fullmatch(slug):
        raise FichaValidationError("invalid entity slug")
    target = f"{target_section}/{slug}.md"
    path = PurePosixPath(target)
    if path.parts[0] != target_section or path.name != f"{slug}.md":
        raise FichaValidationError("unauthorized entity target")
    if existing_targets and target in existing_targets:
        raise FichaValidationError("entity slug collision")
    provenance = candidate.provenance or [provenance_default]
    frontmatter_values = {
        "type": type_label, "schema_version": 1, "id": slug,
        "title": title, "status": "proposed", "provenance": list(provenance),
    }
    # Flow-declared envelope fields. Accepted canon wins; the Author is
    # reviewing a still-proposed entity (``status: proposed``), so an answered
    # minimum that is still a proposal is promoted to the envelope as well —
    # otherwise the file would be written without the OKF minimums. Empty for
    # the character flow, which keeps its exact bytes.
    for field in frontmatter_fields:
        raw = candidate.accepted_canon.get(field, candidate.proposals.get(field))
        if isinstance(raw, Mapping) and "value" in raw:
            raw = raw["value"]
        if isinstance(raw, (str, int, float)) and str(raw).strip():
            frontmatter_values[field] = raw
    # Accents are preserved for the character flow (S3). Every other flow keeps
    # its historical escaped frontmatter bytes exactly (S5).
    frontmatter = "---\n" + yaml.safe_dump(
        frontmatter_values, sort_keys=False,
        allow_unicode=entity_type == "personaje",
    ) + "---\n"
    def section(name: str, values: Mapping[str, Any] | list[Any]) -> str:
        if not values:
            return ""
        return f"## {name}\n\n```yaml\n{yaml.safe_dump(values, sort_keys=False, allow_unicode=False)}```\n\n"
    if entity_type == "personaje":
        body = render_character_body(candidate)
    else:
        body = (
            section("Identity", candidate.accepted_canon) +
            section("Canon Anchors", candidate.accepted_canon) +
            section("Exploratory Friction", candidate.proposals) +
            section("Relationships", candidate.conflicts) +
            section("Unresolved References", candidate.unresolved_references)
        )
    return FichaProposal(target, frontmatter + body, "\n".join((target, title, repr(candidate.accepted_canon), repr(candidate.provenance))))


def serialize_ficha(candidate: CandidateState, *, world: str, slug: str, title: str,
                    existing_targets: set[str] | None = None) -> FichaProposal:
    """Character-flow wrapper over ``serialize_entity`` (byte-identical)."""
    return serialize_entity(
        candidate, world=world, slug=slug, title=title,
        entity_type="personaje", target_section="personajes",
        type_label="Personaje", existing_targets=existing_targets,
    )


def record_transition(state: SessionState, message_type: MessageType, content: Mapping[str, Any]) -> SessionState:
    """Append a typed acceptance/rejection transition to a copied state."""
    state.revision += 1
    state.messages.append(TypedMessage(message_type, dict(content), state.revision))
    return state
